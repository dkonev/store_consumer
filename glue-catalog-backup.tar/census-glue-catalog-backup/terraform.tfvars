### terraform.tfvars

aws_region          = "us-east-1"
environment         = "prod"
project_name        = "glue-backup"
backup_bucket_name  = "my-glue-backup-bucket-12345"
enable_versioning   = true
retention_days      = 30
backup_schedule     = "cron(0 22 * * ? *)"  # 10 PM UTC daily
lambda_timeout      = 900
lambda_memory       = 512
